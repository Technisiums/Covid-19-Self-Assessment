<?php
namespace CoderExpert\Core;

class Installer {
    public static function activate(){
        
    }
}